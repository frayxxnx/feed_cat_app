<?php
defined('IN_WEB') or die();
global $db;
?>
<html>
<head>
	<title><?php echo ($this->get_page_title() ? $this->get_page_title() . ' - ' : '') . SITE_TITLE; ?></title>
	<meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
	<link href="https://preview.tabler.io/dist/css/tabler.min.css?1695847769" rel="stylesheet"/>
</head>
<body class="d-flex justify-content-center align-items-center">
	<div class="col-12 col-lg-9 col-xl-8 col-xxl-7">
		<div class="text-center pb-3">
			<img src="/assets/cat.svg" style="width:48px;" alt="Logo" />
		</div>
		<?php echo $this->get_page_content(); ?>
	</div>
</body>
</html>