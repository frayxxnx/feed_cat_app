<?php
$page->set_page_title('Atzīmēt barošanu');

$vards = get_get('vards', true); // true = tiek pielietots htmlspecialchars
if(!$vards){
	echo '<div class="alert alert-danger">Lūdzu, ievadi savu vārdu.</div>';
	return;
}
?>
<div class="card">
	<div class="card-body">
		<div class="h2 text-center">
			Sveicināti, <?php echo $vards; ?>
		</div>
		<div class="border border-2 border-success rounded-2 px-3 py-2 mb-4">
			<?php
			if(get_post('darbiba') === 'pievienot'){
				$datums = get_post('datums', true);
				$piezimes = get_post('piezimes', true);

				if($datums){ // tikai datums ir obligāts
					$arr = [
						'cilveks_vards' => $vards,
						'datums' => strtotime($datums),
						'piezimes' => $piezimes ?: null
					];

					$db->insert_array('barosana', $arr);
					echo '<div class="alert alert-success">Barošanas reize veiksmīgi pievienota!</div>';
				}else{
					echo '<div class="alert alert-danger">Lūdzu, aizpildi datuma lauku.</div>';
				}
			}
			?>
			<div class="h3">Pievienot barošanas reizi</div>
			<form method="post" class="mb-0">
				<div class="mb-2">
					<label class="form-label">Datums</label>
					<input type="datetime-local" class="form-control" name="datums" value="<?php echo date('Y-m-d H:i'); ?>" style="max-width:250px;" required />
				</div>
				<div class="mb-3">
					<label class="form-label">Piezīmes</label>
					<input type="text" class="form-control" name="piezimes" autocomplete="off" />
				</div>
				<button type="submit" class="btn btn-success" name="darbiba" value="pievienot">Pievienot</button>
			</form>
		</div>

		<div class="h3 mb-2">Barošanas vēsture</div>
		<?php
		if(get_post('dzest')){
			$id = get_post('dzest', true);

			if($id){
				$db->query("DELETE FROM `barosana` WHERE `id` = '".$id."'");
				echo '<div class="alert alert-success">Barošanas reize veiksmīgi dzēsta!</div>';
			}
		}

		$saraksts = [];
		$res = $db->query("SELECT * FROM `barosana` ORDER BY `datums` DESC");
		while($row = $db->fetch($res)){
			$saraksts[] = $row;
		}

		if(!empty($saraksts)){
		?>
		<form method="post" class="table-responsive mb-0">
			<table class="table table-hover">
				<thead>
					<tr>
						<th style="width:1em;"></th>
						<th>Datums</th>
						<th>Cilvēks</th>
						<th>Piezīmes</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($saraksts as $elem){
						echo '<tr>'.
							'<td>'.
								'<button type="submit" class="btn btn-sm btn-danger py-0" name="dzest" value="'.$elem['id'].'">dzēst</button>'.
							'</td>'.
							'<td>'.format_time($elem['datums']).'</td>'.
							'<td>'.$elem['cilveks_vards'].'</td>'.
							'<td>'.$elem['piezimes'].'</td>'.
						'</tr>';
					}
					?>
				</tbody>
			</table>
		</form>
		<?php
		}else{
			echo '<div class="alert alert-danger">Kaķis vēl ne reizi nav barots!</div>';
		}
		?>
	</div>
</div>